from file_reader import Filetext
from child_class import child

# this is property 
file= Filetext("mahmoud",'m.txt')
print(file.filetxt)
# setter
file.filetxt =" lotfy"
print(file.filetxt)

# ^ it will print  mahmoud and lotfy m is the old and l is the updated virstion
for  text in file.text():
    print(text)

print("_"*8)
# text we used for it make the yeild go to the next line


file1= Filetext('ll.text',"")
for text1 in file1.text1():
    print(text1)



